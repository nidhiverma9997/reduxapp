import { combineReducers } from "redux";
import { operationsReducer } from "./todoapp/reducers/Operations";

export const rootReducer =combineReducers({
    operationsReducer,
    //more reducer can be added here
})

