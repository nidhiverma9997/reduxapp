
const initialState=[
    {
        id:1,
        todo: 'Buy Laptop',
        completed : false
    },
    {
        id:2,
        todo: 'Master Rdux',
        completed : false
    },
    {
        id:3,
        todo: 'Watering Plants',
        completed : true
    },
    {
        id:4,
        todo: 'Buy CPU',
        completed : false
    },
    {
        id:5,
        todo: 'Buy Monitor',
        completed : true
    },
];
export const operationsReducer=(state=initialState, action)=>{
switch(action.type){
    default : return state;
}
}