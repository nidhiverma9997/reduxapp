import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Table } from 'react-bootstrap';
import { Icon } from 'react-icons-kit';
import { trash } from 'react-icons-kit/feather/trash';
import { edit2 } from 'react-icons-kit/feather/edit2';
import { removeTodo } from '../redux/todoapp/action/Index';

const Todo = ({ handleEditClick, editFormVisibility }) => {
    const dispatch = useDispatch();
    const todos = useSelector((state) =>
        state.operationsReducer
    );
    console.log('todos>>', todos);
    return (

        <div className='container mt-2'>
            <Table striped bordered hover>
                <thead>
                    {/* <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Action</th>
                    </tr> */}
                </thead>
                <tbody>
                    {
                        todos.map((todo) => (
                            <tr key={todo.id}>
                                <td>
                                    {
                                        editFormVisibility === false && (
                                            <input type='checkbox' checked={todo.completed} />
                                        )
                                    }
                                </td>
                                <td>
                                    <p style={todo.completed === true ? { texDecoration: 'line-through' }
                                        : { texDecoration: 'none' }}>{todo.todo}</p></td>
                                <td>
                                    {
                                        editFormVisibility === false && (
                                            <>
                                                <span onClick={() => handleEditClick(todo)}>
                                                    <Icon icon={edit2} /></span>
                                                <span onClick={() => dispatch(removeTodo(todo.id))}>
                                                    <Icon icon={trash} /></span>
                                            </>
                                        )
                                    }
                                </td>
                            </tr>
                        ))
                    }
                </tbody>
            </Table>
        </div>
    )
}
export default Todo;