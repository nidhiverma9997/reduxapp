import React, { useState } from 'react';

const Form = () => {
    const [todoValue, setTodoValue] = useState('');
    const handleSubmit = (e) => {
        e.preventDefault();
        let date = new Date();
        let time = date.getTime();
        let todoObj = {
            id: '',
            todo: todoValue,
            completed: false
        }
        setTodoValue('');
    }

    return (
        <>
            <div className='container mt-5'>
                <form onSubmit={handleSubmit}>
                    <label>Add your todo-items</label>
                    <div className='row mt-2'>
                        <div className='col-sm-11'>
                            <input type='text' className='form-control' required value={todoValue}
                                onChange={(e) => setTodoValue(e.target.value)} />
                        </div>
                        <div className='col-sm-1'>
                            <button type='submit' className='btn btn-secondary btn-md '>Add</button>
                        </div>

                    </div>
                </form>
            </div>
        </>
    )
}
export default Form;