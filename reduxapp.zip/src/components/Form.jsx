import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { addTodo,handleEditSubmit } from '../redux/todoapp/action/Index';

const Form = ({ editFormVisibility, editTodo, cancelUpdate }) => {
    const dispatch = useDispatch();
    const [todoValue, setTodoValue] = useState('');
    const [editValue, setEditValue] = useState('');

    useEffect(() => {
        setEditValue(editTodo.todo);
    }, [editTodo]);

    const handleSubmit = (e) => {
        e.preventDefault();
        // let date = new Date();
        // let time = date.getTime();
        let todoObj = {
            id: '',
            todo: todoValue,
            completed: false
        }
        setTodoValue('');
        dispatch(addTodo(todoObj))
    }
    const editSubmit = (e) => {
        e.preventDefault();
        let editeObj = {
            id: editTodo.id,
            todo: editValue,
            completed: false
        }
        dispatch(handleEditSubmit(editeObj));
    }
    return (
        <>
            {
                editFormVisibility === false ? (
                    <div className='container mt-5'>
                        <form onSubmit={handleSubmit} >
                            <label>Add your todo-items</label>
                            <div className='row mt-2'>
                                <div className='col-sm-11'>
                                    <input type='text' className='form-control' required value={todoValue}
                                        onChange={(e) => setTodoValue(e.target.value)} />
                                </div>
                                <div className='col-sm-1'>
                                    <button type='submit' className='btn btn-secondary btn-md '>Add</button>
                                </div>
                            </div>
                        </form>
                    </div>
                ) : (
                    <div className='container mt-5'>
                        <form onSubmit={editSubmit}>
                            <label>Update your todo-items</label>
                            <div className='row mt-2'>
                                <div className='col-sm-10'>
                                    <input type='text' className='form-control' required
                                        value={editValue || ''}
                                        onChange={(e) => setEditValue(e.target.value)} 
                                        />
                                </div>
                                <div className='col-sm-1'>
                                    <button type='submit' className='btn btn-secondary btn-md' >Update</button>
                                </div>
                                <div className='col-sm-1'>
                                    <button type='button' className='btn btn-primary btn-md'
                                        onClick={cancelUpdate}>BACK</button>
                                </div>
                            </div>
                        </form> 
                    </div>
                )
            }

        </>
    )
}
export default Form;