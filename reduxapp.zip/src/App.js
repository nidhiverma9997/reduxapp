import './App.css';
import Form from './components/Form';
import Todo from './components/Todo';
import { useSelector, useDispatch } from 'react-redux';
import { deleteAll } from './redux/todoapp/action/Index';
import { useState } from 'react';

function App() {
  const dispatch = useDispatch()
  const todos = useSelector((state) => state.operationsReducer);
  const [editFormVisibility, setEditFormVisibility] = useState(false);
  const [editTodo, setEditTodo] = useState('');

  const handleEditClick = (todo) => {
    setEditFormVisibility(true);
    setEditTodo(todo);
  }

  const cancelUpdate=()=>{
    setEditFormVisibility(false)
  }
  return (
    <div className="App">
      <Form editFormVisibility={editFormVisibility} editTodo={editTodo}
      cancelUpdate={cancelUpdate}/>
      <Todo handleEditClick={handleEditClick} editFormVisibility={editFormVisibility} />
      {
        todos.length > 0 && (
          <button className='btn btn-danger mt-4 mb-4' onClick={() => dispatch(deleteAll())}>DELETE ALL</button>
        )
      }
    </div>
  );
}

export default App;
