import './App.css';
import Form from './components/Form';
import Todo from './components/Todo';
import { useSelector } from 'react-redux';
function App() {
  const birds = useSelector(state => state.birds);
  return (
    <div className="App">
<Form />
<Todo />
    </div>
  );
}

export default App;
